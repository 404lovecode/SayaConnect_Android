# Dicky HDR Studio — Android edition

A free, native Android video exporter inspired by the working **Dicky HDR Color Lab v3** laptop site. It processes clips **on the phone** with Jetpack Media3 and the phone's hardware codecs. It does NOT connect to your laptop, send videos to a server, use a TikTok API, charge credits, or require a subscription.

> **Important: This ZIP contains a ready-to-build Android Studio project, NOT an APK binary.** The build environment where this was prepared did not have an Android SDK or Gradle installed, so no APK was compiled or device-tested here. See the build steps below to create your installable `app-debug.apk` for free.

## What the Android app does

- Choose a clip from Android Files/Gallery (Android storage picker, no broad storage permissions).
- Identify source color transfer **HLG**, **ST 2084/PQ**, or SDR via Android's track metadata. Preview the selected video.
- Apply real **linear-light exposure changes** (−2 to +2 EV in 0.25 EV steps) with Media3's RGB scaling. This may clip bright pixels and does **not** measure actual nits.
- Export portrait **1080×1920** or **2160×3840** with a crop-to-fill or fit-in-frame option; source frame rate is capped at 60 FPS.
- Request H.265/HEVC encoding with AAC audio and MP4 container.
- For HDR source clips, request that Android keep the original HLG or PQ transfer. Alternatively tone-map HDR to SDR as a compatibility option.
- Check the produced file for **BT.2020 + HLG/PQ color transfer + HEVC**. If the phone fell back to SDR, explicitly label it `SDR_FALLBACK` instead of claiming real HDR.
- Save the video to **Movies/DickyHDR** and share through the Android share sheet (select TikTok there if installed, or upload from TikTok yourself).
- Local only: app declares **no INTERNET permission**.

## What's different from your laptop version

| Feature | Android project | Laptop HDR Color Lab v3 |
|---|---|---|
| True on-device processing | Yes, using supported device codecs | FFmpeg on laptop |
| Exposure adjustment | Yes, linear RGB EV | Yes, FFmpeg EV |
| Preserve HLG/PQ source HDR | Supported on compatible phones | Supported |
| HDR to SDR | Supported on compatible phones | Supported |
| **SDR to genuine HDR-compatible PQ/HLG** | **Not implemented** | Implemented as SDR mapped to HDR signal |
| **400/600/1000/1600 nits mapping & metadata authoring** | **Not implemented** | Implemented as an authoring reference |
| HLG ↔ PQ transfer conversion | Not implemented | Supported |
| Dolby Vision dynamic metadata authoring | Not implemented | Not implemented |
| 1080p / 4K output | Yes, device-dependent | Yes |

Android Media3's official guidance says HDR-preserving edits need hardware support and generally Android 13+; if not supported, the library may tone-map to SDR. The app verifies the output. A 4K60 HEVC export may also fail on phones without enough encoder capability. Try 1080p first.

## Easiest free build: Android Studio on laptop

1. Install **Android Studio**: https://developer.android.com/studio . No paid account or Play Store listing is needed to build an APK locally.
2. Extract this ZIP. In Android Studio choose **File → Open** and select the `dicky-hdr-android` folder.
3. Let Android Studio configure **Android SDK API 35**, the Android Gradle Plugin, and **Gradle 8.9**; accept free component downloads. JDK **17** is required (Android Studio includes a compatible JDK).
4. Use **Build → Build Bundle(s) / APK(s) → Build APK(s)**. (On newer Android Studio versions, the menu may read **Build → Build APK(s)**.)
5. Find your generated installable debug APK at:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Copy the APK to your Android phone, open it, and authorize installation from that source when Android asks. No Play Store subscription or developer account is needed for a personal installation.

**Note:** The source archive does not include a Gradle wrapper executable/JAR because it could not be obtained in this environment. If Android Studio asks for Gradle, select Gradle **8.9**. Alternatively build with an installed Gradle 8.9 using `gradle :app:assembleDebug` from the project folder.

## Alternative: Free GitHub Actions APK build (optional)

For users who have an existing GitHub account, this project includes `.github/workflows/build-apk.yml` to compile a signed debug APK on GitHub's Linux runner. Upload the project files to a repository, open **Actions → Build installable Android APK → Run workflow**, then download the `Dicky-HDR-Studio-APK` build artifact. You do **not** need this method if Android Studio is available. GitHub may apply its normal Actions limits and require an account; it is not required to run the app.

## Use on the phone

1. Launch **Dicky HDR Studio**.
2. Tap **Choose video**. Start with an original 10-bit HLG camera clip, like your reference sample. An SDR clip is exported as SDR, never mislabeled HDR.
3. Pick **Preserve source HDR**, try exposure **+0.25 EV**, **1080×1920**, and **Fill 9:16**.
4. Tap **Export MP4**. Keep the app open until it confirms the video has been saved.
5. Look in **Gallery / Movies / DickyHDR**; tap **Share / Post to TikTok** or post manually in the TikTok app. Test with a private upload on an HDR-capable screen first.

Do not assume TikTok will preserve or display HDR just because the exported MP4 is correctly tagged. TikTok may recompress or tone-map the upload.

## Privacy & limitations

- The app requests no Internet permission. No accounts or API keys.
- The Android system file picker is used for read access. Output videos are saved through `MediaStore` to `Movies/DickyHDR`.
- Video previews may differ from true HDR playback on a suitable OLED display.
- Exposure is a mathematical scale in linear light, **not** an actual display nit value, and changing it does not recover clipped highlights from SDR.
- **ProXDR** is not a video codec. **Dolby Vision** requires additional metadata; this Android app **does not** author Dolby Vision.
- The project is designed for API 29+ (Android 10+), but **HDR editing is device-dependent and Android 13+ is recommended**.
- This source project has passed Java **syntax parsing**, XML validation, and package integrity checks, **not** Gradle compilation or Android-device tests (Android SDK was unavailable here).

## Technical details

- Java app with programmatically created dark UI (no web wrapper or local HTTP server).
- Jetpack Media3 `1.11.1` Transformer / Effects / Common; AGP `8.7.3`, Java 17, compileSdk 35.
- HDR pass-through with `Composition.HDR_MODE_KEEP_HDR`, SDR tone mapping with OpenGL.
- Media3 `RgbAdjustment` applies `2^EV` linear RGB scaling before export.
- Source & output inspected via `MediaExtractor`. This checks transfer tags and colorspace, not the picture's measured brightness or encoded bit depth.

Android official sources: [HDR editing](https://developer.android.com/media/implement/editing-app), [Transformer documentation](https://developer.android.com/media/media3/transformer/getting-started), [Media3 release notes](https://developer.android.com/jetpack/androidx/releases/media3).
