package com.dicky.hdr;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.annotation.OptIn;
import androidx.media3.common.Effect;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.effect.Presentation;
import androidx.media3.effect.RgbAdjustment;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.ProgressHolder;
import androidx.media3.transformer.TransformationRequest;
import androidx.media3.transformer.Transformer;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;

/** Native Android HDR editor. Uses Android hardware codecs, never a website or cloud API. */
@OptIn(markerClass = UnstableApi.class)
public class MainActivity extends Activity {
    private static final int REQUEST_PICK = 101;
    private static final int BG = Color.rgb(10, 12, 20);
    private static final int PANEL = Color.rgb(22, 26, 39);
    private static final int ACCENT = Color.rgb(117, 239, 187);
    private static final int SOFT = Color.rgb(161, 171, 194);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private Uri source;
    private Uri savedVideo;
    private VideoInfo sourceInfo;
    private Transformer transformer;
    private File pendingFile;
    private boolean working;
    private boolean fallbackUsed;
    private int evQuarterSteps = 0; // each step is 0.25 EV, from -2 to +2
    private int outputHeight = 1920;
    private boolean crop = true;
    private boolean toSdr;

    private TextView fileInfo;
    private TextView status;
    private TextView evText;
    private TextView details;
    private Spinner formatSpinner;
    private Spinner resolutionSpinner;
    private Spinner framingSpinner;
    private Button exportButton;
    private Button shareButton;
    private Button cancelButton;
    private ProgressBar progress;
    private VideoView preview;

    private static final class VideoInfo {
        int width, height, transfer, standard;
        String mime;
        long durationMs;
        boolean hdr;
        String hdrName;
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        buildUi();
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private GradientDrawable background(int fill, int radius, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radius));
        if (strokeColor != 0) d.setStroke(dp(1), strokeColor);
        return d;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(sp);
        t.setLineSpacing(dp(2), 1f);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void pad(View view, int x, int y) {
        view.setPadding(dp(x), dp(y), dp(x), dp(y));
    }

    private void add(LinearLayout layout, View child, int marginTop) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(marginTop);
        layout.addView(child, p);
    }

    private LinearLayout column() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        return c;
    }

    private LinearLayout card(String title, String subtitle) {
        LinearLayout c = column();
        pad(c, 17, 18);
        c.setBackground(background(PANEL, 20, Color.rgb(45, 52, 72)));
        add(c, text(title, 19, Color.WHITE, true), 0);
        if (subtitle != null) add(c, text(subtitle, 12, SOFT, false), 5);
        return c;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(15);
        b.setTextColor(primary ? BG : Color.WHITE);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(background(primary ? ACCENT : Color.rgb(45, 53, 72), 13, 0));
        b.setMinHeight(dp(51));
        return b;
    }

    private Spinner spinner(String[] values, LinearLayout parent) {
        Spinner s = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, values) {
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                TextView t = (TextView) super.getView(position, convertView, parent);
                t.setTextColor(Color.WHITE);
                t.setTextSize(15);
                t.setPadding(dp(12), dp(12), dp(12), dp(12));
                return t;
            }
        };
        s.setAdapter(adapter);
        s.setBackground(background(Color.rgb(36, 43, 60), 11, 0));
        add(parent, s, 8);
        return s;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout page = column();
        pad(page, 17, 25);
        scroll.addView(page);
        setContentView(scroll);

        add(page, text("●  DICKY  /  HDR LAB", 12, ACCENT, true), 0);
        add(page, text("HDR Studio", 35, Color.WHITE, true), 12);
        add(page, text("Local video grading & TikTok export. No API key. No uploads to a server.", 14, SOFT, false), 6);

        LinearLayout importCard = card("01  Import your video", "Choose footage from your phone. HDR metadata is inspected locally.");
        add(page, importCard, 24);
        Button pickButton = button("＋  Choose video", true);
        add(importCard, pickButton, 14);
        pickButton.setOnClickListener(v -> chooseVideo());
        fileInfo = text("No video selected", 13, SOFT, false);
        add(importCard, fileInfo, 12);
        preview = new VideoView(this);
        preview.setBackgroundColor(Color.BLACK);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, dp(215));
        vp.topMargin = dp(12);
        importCard.addView(preview, vp);
        preview.setVisibility(View.GONE);

        LinearLayout gradeCard = card("02  Grade & frame", "Linear-light exposure adjustment (EV). Works on supported device codecs.");
        add(page, gradeCard, 16);
        evText = text("Exposure   0.00 EV", 15, Color.WHITE, true);
        add(gradeCard, evText, 16);
        SeekBar exposureSlider = new SeekBar(this);
        exposureSlider.setMax(16);
        exposureSlider.setProgress(8);
        exposureSlider.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        exposureSlider.setThumbTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        add(gradeCard, exposureSlider, 4);
        add(gradeCard, text("-2 EV                               0                               +2 EV", 10, SOFT, false), 0);
        exposureSlider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                evQuarterSteps = progress - 8;
                evText.setText(String.format(Locale.US, "Exposure   %+.2f EV", evQuarterSteps * 0.25f));
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        add(gradeCard, text("Video mode", 13, SOFT, true), 15);
        formatSpinner = spinner(new String[]{"Select video first"}, gradeCard);
        add(gradeCard, text("Export resolution", 13, SOFT, true), 15);
        resolutionSpinner = spinner(new String[]{"1080 × 1920 · Recommended", "2160 × 3840 · 4K, slower"}, gradeCard);
        resolutionSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int position, long id) { outputHeight = position == 0 ? 1920 : 3840; }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });
        add(gradeCard, text("Framing", 13, SOFT, true), 15);
        framingSpinner = spinner(new String[]{"Fill 9:16 · Crop", "Fit 9:16 · Add borders"}, gradeCard);
        framingSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int position, long id) { crop = position == 0; }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });
        add(gradeCard, text("Nit targets (400–1,600) & SDR → HDR conversion: use the laptop FFmpeg edition. Android Media3 cannot author those controls equivalently.", 12, SOFT, false), 15);

        LinearLayout outCard = card("03  Export for TikTok", "HEVC (H.265) + AAC • MP4 • device hardware encoder");
        add(page, outCard, 16);
        exportButton = button("Export MP4", true);
        add(outCard, exportButton, 14);
        exportButton.setOnClickListener(v -> exportVideo());
        exportButton.setEnabled(false);
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        add(outCard, progress, 13);
        progress.setVisibility(View.GONE);
        status = text("Ready when you select a clip.", 13, SOFT, false);
        add(outCard, status, 10);
        cancelButton = button("Cancel export", false);
        add(outCard, cancelButton, 10);
        cancelButton.setVisibility(View.GONE);
        cancelButton.setOnClickListener(v -> cancelExport());
        shareButton = button("Share / Post to TikTok", false);
        add(outCard, shareButton, 10);
        shareButton.setEnabled(false);
        shareButton.setOnClickListener(v -> shareVideo());
        details = text("No subscriptions, cloud processing, or TikTok login in this app. Upload using the TikTok app after export.", 12, SOFT, false);
        add(outCard, details, 13);
        add(page, text("HDR export requires a compatible phone (normally Android 13+). HDR-to-SDR fallback is detected and labeled. Export nits cannot force screen brightness or prevent TikTok recompression.", 12, SOFT, false), 16);
    }

    private void chooseVideo() {
        if (working) { status.setText("Cancel the current export first."); return; }
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("video/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(intent, REQUEST_PICK); }
        catch (ActivityNotFoundException ex) { status.setText("No video file picker is installed."); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_PICK || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        source = data.getData();
        savedVideo = null;
        shareButton.setEnabled(false);
        try {
            getContentResolver().takePersistableUriPermission(source, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (SecurityException ignored) { }
        try {
            sourceInfo = inspect(source);
            String name = queryFileName(source);
            String value = name + "\n" + sourceInfo.width + " × " + sourceInfo.height
                    + "  •  " + (sourceInfo.durationMs / 1000) + " s  •  "
                    + sourceInfo.mime + "\n" + sourceInfo.hdrName;
            fileInfo.setText(value);
            preview.setVisibility(View.VISIBLE);
            preview.setVideoURI(source);
            MediaController controller = new MediaController(this);
            controller.setAnchorView(preview);
            preview.setMediaController(controller);
            if (sourceInfo.hdr) {
                formatSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                        new String[]{"Preserve source HDR · " + sourceInfo.hdrName, "Tone-map HDR → SDR"}));
                if (Build.VERSION.SDK_INT < 33) {
                    status.setText("This phone runs an older Android version. HDR edits may fall back to SDR.");
                } else {
                    status.setText("HDR source detected. Export will verify HDR output.");
                }
            } else {
                formatSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                        new String[]{"SDR (HDR source needed for real HDR)"}));
                status.setText("SDR video detected. This app will export SDR, not relabel it HDR.");
            }
            exportButton.setEnabled(true);
        } catch (Exception e) {
            sourceInfo = null;
            preview.setVisibility(View.GONE);
            fileInfo.setText("Unable to inspect video: " + e.getMessage());
            exportButton.setEnabled(false);
        }
    }

    private VideoInfo inspect(Uri uri) throws IOException {
        MediaExtractor extractor = new MediaExtractor();
        try {
            extractor.setDataSource(this, uri, null);
            for (int i = 0; i < extractor.getTrackCount(); i++) {
                MediaFormat track = extractor.getTrackFormat(i);
                String mime = track.getString(MediaFormat.KEY_MIME);
                if (mime == null || !mime.startsWith("video/")) continue;
                VideoInfo info = new VideoInfo();
                info.mime = mime;
                info.width = track.containsKey(MediaFormat.KEY_WIDTH) ? track.getInteger(MediaFormat.KEY_WIDTH) : 0;
                info.height = track.containsKey(MediaFormat.KEY_HEIGHT) ? track.getInteger(MediaFormat.KEY_HEIGHT) : 0;
                info.durationMs = track.containsKey(MediaFormat.KEY_DURATION) ? track.getLong(MediaFormat.KEY_DURATION) / 1000 : 0;
                info.transfer = track.containsKey(MediaFormat.KEY_COLOR_TRANSFER) ? track.getInteger(MediaFormat.KEY_COLOR_TRANSFER) : -1;
                info.standard = track.containsKey(MediaFormat.KEY_COLOR_STANDARD) ? track.getInteger(MediaFormat.KEY_COLOR_STANDARD) : -1;
                info.hdr = info.transfer == MediaFormat.COLOR_TRANSFER_HLG || info.transfer == MediaFormat.COLOR_TRANSFER_ST2084;
                info.hdrName = info.transfer == MediaFormat.COLOR_TRANSFER_HLG ? "HLG HDR"
                        : info.transfer == MediaFormat.COLOR_TRANSFER_ST2084 ? "PQ / HDR10" : "SDR / HDR unspecified";
                return info;
            }
            throw new IOException("No video track found");
        } finally { extractor.release(); }
    }

    private String queryFileName(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) return cursor.getString(0);
        } catch (Exception ignored) { }
        return "Selected video";
    }

    private boolean isSdrOutputSelected() { return sourceInfo != null && ( !sourceInfo.hdr || formatSpinner.getSelectedItemPosition() == 1 ); }

    private void exportVideo() {
        if (working || source == null || sourceInfo == null) return;
        if (sourceInfo.hdr && !isSdrOutputSelected() && Build.VERSION.SDK_INT < 31) {
            status.setText("Preserving HDR while editing requires Android 12+ and compatible hardware. Choose SDR output.");
            return;
        }
        working = true;
        savedVideo = null;
        fallbackUsed = false;
        exportButton.setEnabled(false);
        shareButton.setEnabled(false);
        cancelButton.setVisibility(View.VISIBLE);
        progress.setProgress(0);
        progress.setVisibility(View.VISIBLE);
        status.setText("Starting on-device export… Keep this app open.");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        toSdr = isSdrOutputSelected();
        try {
            ArrayList<Effect> effects = new ArrayList<>();
            float ev = evQuarterSteps * 0.25f;
            if (evQuarterSteps != 0) {
                float scale = (float) Math.pow(2d, ev);
                effects.add(new RgbAdjustment.Builder()
                        .setRedScale(scale).setGreenScale(scale).setBlueScale(scale).build());
            }
            int width = outputHeight * 9 / 16;
            effects.add(Presentation.createForWidthAndHeight(width, outputHeight,
                    crop ? Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP : Presentation.LAYOUT_SCALE_TO_FIT));
            EditedMediaItem edited = new EditedMediaItem.Builder(MediaItem.fromUri(source))
                    .setFrameRate(60)
                    .setEffects(new Effects(Collections.emptyList(), effects))
                    .build();
            Composition composition = new Composition.Builder(
                    androidx.media3.transformer.EditedMediaItemSequence.withAudioAndVideoFrom(Collections.singletonList(edited)))
                    .setHdrMode(toSdr ? Composition.HDR_MODE_TONE_MAP_HDR_TO_SDR_USING_OPEN_GL
                            : Composition.HDR_MODE_KEEP_HDR)
                    .build();
            File folder = new File(getCacheDir(), "exports");
            if (!folder.exists() && !folder.mkdirs()) throw new IOException("Cannot create export folder");
            pendingFile = new File(folder, "dicky_" + System.currentTimeMillis() + ".mp4");
            transformer = new Transformer.Builder(this)
                    .setVideoMimeType(MimeTypes.VIDEO_H265)
                    .setAudioMimeType(MimeTypes.AUDIO_AAC)
                    .addListener(new Transformer.Listener() {
                        @Override public void onCompleted(Composition composition, ExportResult result) {
                            if (!working) return;
                            progress.setProgress(100);
                            status.setText("Encoding completed. Verifying and saving video…");
                            cancelButton.setVisibility(View.GONE);
                            transformer = null;
                            finishExport();
                        }
                        @Override public void onError(Composition composition, ExportResult result, ExportException exception) {
                            showFailure(exception.getMessage() == null ? "Codec export failed" : exception.getMessage());
                        }
                        @Override public void onFallbackApplied(Composition composition,
                                TransformationRequest original, TransformationRequest fallback) {
                            fallbackUsed = true;
                            details.setText("The phone applied an export fallback. The saved video will be inspected for actual HDR tags.");
                        }
                    }).build();
            transformer.start(composition, pendingFile.getAbsolutePath());
            pollProgress();
        } catch (Exception e) { showFailure(e.getMessage() == null ? e.toString() : e.getMessage()); }
    }

    private void pollProgress() {
        if (!working || transformer == null) return;
        try {
            ProgressHolder holder = new ProgressHolder();
            int state = transformer.getProgress(holder);
            if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                progress.setProgress(Math.min(99, holder.progress));
                status.setText("Encoding on your phone… " + holder.progress + "%");
            } else if (state == Transformer.PROGRESS_STATE_WAITING_FOR_AVAILABILITY) {
                status.setText("Preparing hardware encoder…");
            }
        } catch (Exception ignored) { }
        if (working) handler.postDelayed(this::pollProgress, 600);
    }

    private void finishExport() {
        File file = pendingFile;
        boolean expectedHdr = sourceInfo != null && sourceInfo.hdr && !toSdr;
        new Thread(() -> {
            try {
                VideoInfo verified = inspect(Uri.fromFile(file));
                boolean hdrRetained = verified.hdr && verified.standard == MediaFormat.COLOR_STANDARD_BT2020
                        && "video/hevc".equals(verified.mime)
                        && sourceInfo != null && verified.transfer == sourceInfo.transfer;
                // An HDR failure must not be represented as a successful HDR export.
                String suffix = expectedHdr && !hdrRetained ? "SDR_FALLBACK" : verified.hdr ? "HDR" : "SDR";
                String displayName = "Dicky_" + suffix + "_" + System.currentTimeMillis() + ".mp4";
                Uri output = saveVideo(file, displayName);
                handler.post(() -> {
                    savedVideo = output;
                    working = false;
                    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    exportButton.setEnabled(true);
                    cancelButton.setVisibility(View.GONE);
                    shareButton.setEnabled(true);
                    status.setText("Saved to Movies / DickyHDR / " + displayName);
                    String note = verified.width + "×" + verified.height + " · " + verified.mime + " · " + verified.hdrName;
                    if (expectedHdr && !hdrRetained) {
                        note += "\n⚠ HDR was NOT preserved by this phone. Output is labeled SDR fallback.";
                    } else if (expectedHdr && hdrRetained) {
                        note += "\n✓ The saved MP4 has BT.2020 + an HDR transfer tag.";
                    }
                    if (fallbackUsed) note += "\nThe device changed one or more export settings.";
                    details.setText(note);
                });
            } catch (Exception e) {
                handler.post(() -> showFailure("Saving export failed: " + e.getMessage()));
            } finally {
                if (file != null) file.delete();
            }
        }).start();
    }

    private Uri saveVideo(File sourceFile, String displayName) throws IOException {
        ContentResolver resolver = getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, displayName);
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/DickyHDR");
        values.put(MediaStore.Video.Media.IS_PENDING, 1);
        Uri uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new IOException("Unable to create MediaStore entry");
        try {
            try (FileInputStream input = new FileInputStream(sourceFile);
                 OutputStream out = resolver.openOutputStream(uri)) {
                if (out == null) throw new IOException("Unable to open video destination");
                byte[] buffer = new byte[1024 * 1024];
                int bytes;
                while ((bytes = input.read(buffer)) != -1) out.write(buffer, 0, bytes);
            }
            ContentValues complete = new ContentValues();
            complete.put(MediaStore.Video.Media.IS_PENDING, 0);
            resolver.update(uri, complete, null, null);
            return uri;
        } catch (Exception e) {
            resolver.delete(uri, null, null);
            if (e instanceof IOException) throw (IOException) e;
            throw new IOException(e);
        }
    }

    private void showFailure(String error) {
        working = false;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        exportButton.setEnabled(sourceInfo != null);
        cancelButton.setVisibility(View.GONE);
        progress.setVisibility(View.GONE);
        shareButton.setEnabled(savedVideo != null);
        status.setText("Export failed: " + error);
        details.setText("Try 1080p, zero exposure, or SDR output. HDR encoding support differs between Android devices.");
        if (pendingFile != null) pendingFile.delete();
        transformer = null;
    }

    private void cancelExport() {
        if (transformer != null) transformer.cancel();
        working = false;
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        exportButton.setEnabled(sourceInfo != null);
        cancelButton.setVisibility(View.GONE);
        progress.setVisibility(View.GONE);
        status.setText("Export canceled.");
        if (pendingFile != null) pendingFile.delete();
        transformer = null;
    }

    private void shareVideo() {
        if (savedVideo == null) return;
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("video/mp4");
        send.putExtra(Intent.EXTRA_STREAM, savedVideo);
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(send, "Share finished video"));
    }

    @Override protected void onDestroy() {
        if (working && transformer != null) transformer.cancel();
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
